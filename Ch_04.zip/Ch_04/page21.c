#include <stdio.h>

int main()
{
    int number;

    do
    {
        scanf("%d", &number);
    } while (number != 20);


    /*scanf("%d", &number);
    while (number != 20)
    {
        scanf("%d", &number);
    }*/


   return 0;
}
