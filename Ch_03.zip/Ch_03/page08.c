#include <stdio.h>

int main()
{
    int i = 5, j = 5;

    printf("i: %d, j: %d\n", i, j); 
    i++;
    j--;
       
    printf("i: %d, j: %d\n", i, j);

    return 0;
}
