#include <stdio.h>

int main()
{
    int i;

    i = 5;
    printf(" i = %d \n", i);

    printf(" 3 + 5 = %d \n", 3+5);

    printf(" 3 - 5 = %d \n", 3-5);

    printf(" 3 * 5 = %d \n", 3*5);

    printf(" 3 / 5 = %d \n", 3/5);

    printf(" 3 %% 5 = %d \n", 3%5);

    printf(" -i = %d \n", -i);

    return 0;
}
