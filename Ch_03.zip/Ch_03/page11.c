#include <stdio.h>

int main()
{
    int a,b,c,d;

    printf(" 6/2(1+2) = %d \n", 6/2*(1+2) );

    b=3; c=4; d=5;
    printf(" %d \n", b+c*d );
    printf(" %d \n", (b+c)*d );

    return 0;
}
