
//int main(int argc, char **argv)
int main(int argc, char *argv[])
//int main()
{
    return 0;
}

