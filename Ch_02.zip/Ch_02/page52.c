#include <stdio.h>

int main ()
{
  char ch;

  printf("input a symbol: ");
  ch = getchar();
  putchar(ch);

  return 0;
}

