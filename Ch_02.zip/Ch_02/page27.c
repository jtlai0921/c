#include <stdio.h>

int main(void) 
{
   int n;                  	

   n = '1';                 

   printf(" %d %c", n, n);

   return 0;
}

