#include <stdio.h>

int main()
{
    int a, b;
    int ch;
    
    scanf("%d %d", &a, &b);   
    //scanf("%d %d%c", &a, &b, &ch);    
    //scanf("%d %d%*c", &a, &b);
    
    ch = getchar();     // scanf("%c", &ch)
    printf(" %d %c \n", ch, ch);

    return 0;
}

