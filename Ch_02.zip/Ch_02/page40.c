#include <stdio.h>

int main(void)
{
    int i = 5, j = 2, k = 3;
    char a = '7';

    printf("\t %d + %d equals %c\n", j, i, a);
    printf("%d", i+j+k);

    return 0;
}

